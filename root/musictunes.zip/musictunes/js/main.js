/************************************
Index:
    1. Variables
    2. Automatic run
      $(document).ready(function() {})
    3. Search petition
      => makeSearchURL()
      => makeSearch(anchorID, url) 
    4. Card Generator
      => makeCard(object)
      4.1. Card Generator Support Functions
        => makeCardSong(object)
        => makeCardArtist(object)
        => makeCardAlbum(object)
        => makeCardVideo(object)
      4.2. Card favorite generator support
        => favoriteClick(checkbox, object)
        => addFavorite(object)
        => removeFavorite(object)
        => loadFavorites()
        => saveFavorites()
        => showFavorites()
      5. Other functions
        => fillCountries()
    
    
*************************************/

//S> 1.Variables
const srcItunesLogo = 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/ITunes_logo.svg/438px-ITunes_logo.svg.png'

const favorites = loadFavorites()

//E> 1.Variables
/******************************************************************************X*/

/******************************************************************************X*/
//S> 2.Automatic run
$(document).ready(function () {
  // We add the countries in the select input...
  fillCountries()

  $('#termInput').on('keyup', makeSearch)
  $('#checkCountry').on('change', makeSearch)
  $('#checkContent').on('change', makeSearch)
  $('#checkLimit').on('change', makeSearch)
  $('#entityInput').on('change', makeSearch)

  $('#countryInput').on('change', function () {
    if ($('#checkCountry').is(':checked')) makeSearch()
  })

  $('#explicitInput').on('change', function () {
    if ($('#checkContent').is(':checked')) makeSearch()
  })

  $('#limitInput').on('change', function () {
    if ($('#checkLimit').is(':checked')) makeSearch()
  })

  $('#toogleFilter').on('click', function () {
    if ($('.subheader').css('display') === 'none') {
      $('.subheader').fadeIn().css({ 'display': 'flex' })
    } else {
      $('.subheader').css({ 'display': 'none' })
    }
  })

  $('#searchFav').on('click', showFavorites)

  // Start showing the favorities
  showFavorites()
})
//E> 3.Automatic run
/******************************************************************************X*/

/******************************************************************************X*/
//S> 3. Search Petition

function makeSearchURL() {
  const baseURL = "https://itunes.apple.com/search?"
  const parameters = []
  const attribute = {
    'song': 'songTerm',
    'musicArtist': 'artistTerm',
    'album': 'albumTerm',
    'musicVideo': 'songTerm'
  }

  // 1. Term
  const term = $('#termInput').val()
  if (term === '') return
  parameters.push('term=' + term.replace(' ', '+'))

  // 2. Media
  parameters.push('media=music')
  
  // 3. Entity
  const type = $('#entityInput').val()
  if (type === '') return
  parameters.push('entity=' + type)

  // 4. Attribute
  parameters.push('attribute=' + attribute[type])

  // 5. Country
  if ($('#checkCountry').is(':checked')) {
    parameters.push('country=' + $('#countryInput').val())
  }

  // 6. Explicit
  if ($('#checkContent').is(':checked')) {
    parameters.push('explicit=' + $('#explicitInput').val())
  }

  // 7. Limit
  if ($('#checkLimit').is(':checked')) {
    parameters.push('limit=' + $('#limitInput').val())
  } else {
    parameters.push('limit=5')
  }

  return baseURL + parameters.join('&')
}

function makeSearch() {
  const url = makeSearchURL()
  const cardsDisplayer = $('#cardsDisplayer')
  const originalSearch = $('#termInput').val()

  $.ajax({
    url: url,
    dataType: 'jsonp',
    success: function (data) {
      if (originalSearch !== $('#termInput').val()) return

      cardsDisplayer.empty()

      for (let i = 0; i < data.resultCount; i++) {
        cardsDisplayer.append(
          makeCard(data.results[i])
        )
      }
    },
    fail: function () {
      cardsDisplayer.append($('<p>', { text: 'Not found...' })
      )
    }
  })
}

//E> 3. Search Petition
/******************************************************************************X*/

/******************************************************************************X*/
//S> 4. Card Generator

function makeCard(object) {
  switch (object.wrapperType) {
  case 'track':
    return object.kind === 'song' ? makeCardSong(object) : makeCardVideo(object)
  case 'artist':
    return makeCardArtist(object)
  case 'collection':
    return makeCardAlbum(object)
  }
}

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
//S> 4.1. Card Generator Support Functions
function makeCardSong(object) {
  //S> PreCreating info
  let cover = "url(" + object.artworkUrl100 + ")";
  cover = cover.replace("100x100bb", "500x500bb");
  let artist =
    "<span data-artistId='" +
    object.artistId +
    "'>" +
    object.artistName +
    "</span>";
  let srcURL = object.previewUrl;
  let album = "<span>From: " + object.collectionName + "</span>";
  var f = new Date(object.releaseDate);
  let dateString =
    f.getDate() + "/" + (f.getMonth() + 1) + "/" + f.getFullYear();
  let releaseDate = "<span>" + dateString + "</span>";
  let price = "<span>" + (object.trackPrice < 0 ? "Free" : object.trackPrice) + '<i class="uil uil-dollar-alt"></i></price>';
  let isFavorite = favorites.indexOf(object) !== -1
  //E> PreCreating info

  /*
  Flip card:
  ¡Hi! We are going to create a complicated flip card with JQuery!!!
  We need two faces... Two divs... One flip__card__front and the other flip__card__header.
  When we have this two divs... We are going to assemble in the flip_-card > flip__card__inner div! 
  */

  //S> CREATING FRONT CARD
  /*
  In this part we are going to put the artist, the name of song and the cover... With a eleggant useless itunes img
  */
  var flipCardFront = $("<div>", { class: "flip__card__front" })
    //We append the elements in the front card in three divs: header, body and footer
    .append(
      //S> CARD HEADER
      $("<div>", { class: "flip__card__header" }).css({
        "background-image": cover
      })
      //E> CARD HEADER
    )
    .append(
      //S> CARD BODY
      $("<div>", { class: "flip__card__body" })
        .append($("<h3>", { class: "card__title", html: object.trackName }))
        .append($("<p>", { class: "", html: artist }))
        .append($("<p>", { class: "card__date", html: releaseDate }))
      //E> CARD FOOTER
    )
    .append(
      $("<div>", { class: "flip__card__footer" }).append(
        $("<a>", { href: object.trackViewUrl, target: "_blank" }).append(
          $("<img>", { src: srcItunesLogo, width: "25px", height: "25px" })
        )
      )
    );
  //E> CREATING FRONT CARD

  //S> CREATING BACK CARD
  /*
  In this part we are going to put the other elements...
  */
  var flipCardBack = $("<div>", { class: "flip__card__back" })
    //We append the elements in the front card in three divs: header, body and footer
    .append(
      //S> CARD HEADER
      $("<div>", { class: "flip__card__header" }).css({
        "background-image": cover
      })
      //E> CARD HEADER
    )
    .append(
      //S> CARD BODY
      $("<div>", { class: "flip__card__body" })
        .append($("<p>", { html: album }))
        .append(
          //We put the audio element
          $("<audio>", { controls: true, preload: "none" })
            .css({ width: "100%" })
            .append($("<source>", { src: srcURL }))
          //End put audio element
        )
        .append(
          $("<p>", { html: price })
        )
      //E> CARD BODY
    )
    .append(
      $("<div>", { class: "flip__card__footer" }).append(
        $("<a>", { href: object.trackViewUrl, target: "_blank" }).append(
          $("<img>", { src: srcItunesLogo, width: "25px", height: "25px" })
        )
      )
    )
    .append(
      $('<label>').addClass('checkbox-label').append(
        $('<input>').attr({ type: 'checkbox', checked: isFavorite }).on('change', function () { favoriteClick(this, object) }),
        $('<span>').addClass('checkbox-favortie')
      )
    )
  //E> CREATING BACK CARD

  /*
  ¡Hi! We are going to assemble the two parts in one returnable variable :)
  */
  var card = $("<div>", { class: "flip__card" }).append(
    $("<div>", { class: "flip__card__inner" })
      .append(flipCardFront)
      .append(flipCardBack)
  );
  return card;
}

function makeCardArtist(object) {
  //S> PreCreating info
  let cover = "url(https://i.imgur.com/38B5Lrg.png)";
  let artistName = object.artistName;
  let artist = "<span data-artistId='" + object.artistId + "'>" + artistName +
    "</span>";
  let isFavorite = favorites.indexOf(object) !== -1
  let genre = object.primaryGenreName;
  //E> PreCreating info

  var card = $("<div>", { class: "card" })
    .append(
      $("<div>", { class: "card__header" })
        .css({ "background-image": cover })
        //S> CARD HEADER ELEMENTS
        .append(
          $('<label>').addClass('checkbox-label').append(
            $('<input>').attr({ type: 'checkbox', checked: isFavorite }).on('change', function () { favoriteClick(this, object) }),
            $('<span>').addClass('checkbox-favortie')
          )
        )
      //E> CARD HEADER ELEMENTS
    )
    .append(
      $("<div>", { class: "card__body" })

        //S> CARD BODY ELEMENTS
        .append(
          $("<h3>", { class: "card__title", html: artistName })
        )
        .append(
          $("<p>", { html: genre })
        )

      //E> CARD BODY ELEMENTS
    )
    .append(
      $("<div>", { class: "card__footer" }).append(
        $("<a>", { href: object.artistLinkUrl, target: "_blank" }).append(
          $("<img>", { src: srcItunesLogo, width: "25px", height: "25px" })
        )
      )
    )

  return card;
}

function makeCardAlbum(object) {
  //S> PreCreating info
  let trackNumber = object.trackCount + " songs"
  let albumName = object.collectionName;
  var f = new Date(object.releaseDate);
  let dateString =
    f.getDate() + "/" + (f.getMonth() + 1) + "/" + f.getFullYear();
  let releaseDate = "<span>" + dateString + "</span>";

  let price = "<span>" + (object.collectionPrice < 0 ? "Free" : object.collectionPrice) + '<i class="uil uil-dollar-alt"></i></price>';
  let cover = "url(" + object.artworkUrl100 + ")";
  let artistName = object.artistName;
  let artist = "<span data-artistId='" + object.artistId + "'>" + artistName +
    "</span>";
  cover = cover.replace("100x100bb", "500x500bb");
  let isFavorite = favorites.indexOf(object) !== -1
  //E> PreCreating info

  var card = $("<div>", { class: "card" })
    .append(
      $("<div>", { class: "card__header" })
        .css({ "background-image": cover })
        //S> CARD HEADER ELEMENTS
        .append($("<h3>", { class: "card__title", html: object.trackName }))
      //E> CARD HEADER ELEMENTS
    )
    .append(
      $("<div>", { class: "card__body" })
        //S> CARD BODY ELEMENTS
        .append($("<p>", { class: "card__date", html: releaseDate }))
        .append($("<h3>", { class: "card_title", html: albumName }))
        .append($("<p>", { html: artist }))
        .append($("<p>", { class: "card_track_num", html: trackNumber }))
        .append($("<p>", { class: "card_price", html: price }))

      //E> CARD BODY ELEMENTS
    )
    .append(
      $("<div>", { class: "card__footer" }).append(
        $("<a>", { href: object.collectionViewUrl, target: "_blamk" }).append(
          $("<img>", { src: srcItunesLogo, width: "25px", height: "25px" })
        )
      )
    )
    .append(
      $('<label>').addClass('checkbox-label').append(
        $('<input>').attr({ type: 'checkbox', checked: isFavorite }).on('change', function () { favoriteClick(this, object) }),
        $('<span>').addClass('checkbox-favortie')
      )
    )
  return card;
}

function makeCardVideo(object) {
  //S> PreCreating info
  let cover = "url(" + object.artworkUrl100 + ")";
  cover = cover.replace("100x100bb", "500x500bb");
  let artist =
    "<span data-artistId='" +
    object.artistId +
    "'>" +
    object.artistName +
    "</span>";
  let srcURL = object.previewUrl;
  let album = "<span>From: " + (object.collectionName ? object.collectionName : 'None') + "</span>";
  var f = new Date(object.releaseDate);
  let dateString =
    f.getDate() + "/" + (f.getMonth() + 1) + "/" + f.getFullYear();
  let releaseDate = "<span>" + dateString + "</span>";
  let price = "<span>" + (object.trackPrice ? (object.trackPrice < 0 ? "Free" : object.trackPrice) : 'None') + '<i class="uil uil-dollar-alt"></i></price>';
  let isFavorite = favorites.indexOf(object) !== -1
  //E> PreCreating info

  /*
  Flip card:
  ¡Hi! We are going to create a complicated flip card with JQuery!!!
  We need two faces... Two divs... One flip__card__front and the other flip__card__header.
  When we have this two divs... We are going to assemble in the flip_-card > flip__card__inner div! 
  */

  //S> CREATING FRONT CARD
  /*
  In this part we are going to put the artist, the name of song and the cover... With a eleggant useless itunes img
  */
  var flipCardFront = $("<div>", { class: "flip__card__front" })
    //We append the elements in the front card in three divs: header, body and footer
    .append(
      //S> CARD HEADER
      $("<div>", { class: "flip__card__header" }).css({
        "background-image": cover
      })
      //E> CARD HEADER
    )
    .append(
      //S> CARD BODY
      $("<div>", { class: "flip__card__body" })
        .append($("<h3>", { class: "card__title", html: object.trackName }))
        .append($("<p>", { class: "", html: artist }))
      //E> CARD BODY
    )
    .append(
      $("<div>", { class: "flip__card__footer" }).append(
        $("<a>", { href: object.trackViewUrl, target: "_blamk" }).append(
          $("<img>", { src: srcItunesLogo, width: "25px", height: "25px" })
        )
      )
    )
  //E> CREATING FRONT CARD

  //S> CREATING BACK CARD
  /*
  In this part we are going to put the other elements...
  */
  var flipCardBack = $("<div>", { class: "flip__card__back" })
    //We append the elements in the front card in three divs: header, body and footer
    .append(
      //S> CARD HEADER
      $("<div>", { class: "flip__card__header" }).css({
        "background-image": "none",
        "background-color": "black"
      }).append(
        $("<video>", { controls: true, class: "flip__card__video", preload: "none" })
          //.css({ width: "100%", height: "135px", "border-radius:": "25px" })
          .append($("<source>", { src: srcURL }))
        //End put audio element
      )
      //E> CARD HEADER
    )
    .append(
      //S> CARD BODY
      $("<div>", { class: "flip__card__body" })
        .append(
          $("<p>", { html: album })
        ).append(
          $("<p>", { html: price })
        )
      //E> CARD BODY
    )
    .append(
      $("<div>", { class: "flip__card__footer" }).append(
        $("<a>", { href: object.trackViewUrl, target: "_blank" }).append(
          $("<img>", { src: srcItunesLogo, width: "25px", height: "25px" })
        )
      )
    )
    .append(
      $('<label>').addClass('checkbox-label').append(
        $('<input>').attr({ type: 'checkbox', checked: isFavorite }).on('change', function () { favoriteClick(this, object) }),
        $('<span>').addClass('checkbox-favortie')
      )
    )
  //E> CREATING BACK CARD

  /*
  ¡Hi! We are going to assemble the two parts in one returnable variable :)
  */
  var card = $("<div>", { class: "flip__card" }).append(
    $("<div>", { class: "flip__card__inner" })
      .append(flipCardFront)
      .append(flipCardBack)
  );
  return card;
}
//E> 4.1. Card Generator Support Functions
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/
//S> 4.2. Card Favorite Generator Functions
function favoriteClick(checkbox, object) {
  if (checkbox.checked) addFavorite(object)
  else removeFavorite(object)
}

function addFavorite(object) {
  const index = favorites.indexOf(object)
  if (index !== -1) return
  favorites.push(object)
  saveFavorites()
}

function removeFavorite(object) {
  const index = favorites.indexOf(object)
  favorites.splice(index, 1)
  saveFavorites()
}

function loadFavorites() {
  const data = localStorage.getItem('favorites')
  return data ? JSON.parse(data) : []
}

function saveFavorites() {
  localStorage.setItem('favorites', JSON.stringify(favorites))
}

function showFavorites() {
  $('#cardsDisplayer').empty()
  for (let i = 0; i < favorites.length; i++) {
    let card = makeCard(favorites[i])
    $('#cardsDisplayer').append(card)
  }
}
//E> 4.1. Card Favorite Generator Functions
/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

//E> 4. Card Generator
/******************************************************************************X*/


/******************************************************************************X*/
//S> 5. Other functions
function fillCountries() {
  $.ajax('https://www.liferay.com/api/jsonws/country/get-countries/')
  .done(function (data) {
    $('#countryInput').empty()
    for (let i = 0; i < data.length; i++) {
      const country = data[i]
      $('#countryInput').append(
        $('<option>', { value: country.a2, text: country.nameCurrentValue })
      )
    }
  })
  .fail(function () {
    console.log('Fail country find!')
  })
}
